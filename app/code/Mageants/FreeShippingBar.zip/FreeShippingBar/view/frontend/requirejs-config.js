var config = {
    "map": {
        '*': {
            'freeshippingbar' :'Mageants_FreeShippingBar/js/freeshippingbar'
        }
    },
    "shim":{
        'Mageants_FreeShippingBar/js/freeshippingbar': ["jquery"]
    }
};