<?php
 /**
  * @category Mageants FreeShippingBar
  * @package Mageants_FreeShippingBar
  * @copyright Copyright (c) 2019 Mageants
  * @author Mageants Team <support@mageants.com>
  */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mageants_FreeShippingBar',
    __DIR__
);
